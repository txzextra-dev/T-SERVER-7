'use strict';
// T SERVER - one-file backend for T CALL. Needs Node 22.5+ (built-in SQLite) and the "ws" package.
const http=require('http'),https=require('https'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const {DatabaseSync}=require('node:sqlite');const {WebSocketServer}=require('ws');
const PORT=process.env.PORT||3000,DIR=process.env.DATA_DIR||path.join(__dirname,'data');fs.mkdirSync(DIR,{recursive:true});
const db=new DatabaseSync(path.join(DIR,'tserver.db'));
db.exec(`PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,u TEXT UNIQUE,pw TEXT,role TEXT DEFAULT 'user',banned INTEGER DEFAULT 0,bal REAL DEFAULT 0,vnum TEXT DEFAULT '',prefs TEXT DEFAULT '{}',at INTEGER);
CREATE TABLE IF NOT EXISTS contacts(id INTEGER PRIMARY KEY,owner TEXT,name TEXT,phone TEXT);
CREATE TABLE IF NOT EXISTS calls(id INTEGER PRIMARY KEY,caller TEXT,callee TEXT,num TEXT,at INTEGER,dur INTEGER DEFAULT 0,cost REAL DEFAULT 0,st TEXT,line TEXT);
CREATE TABLE IF NOT EXISTS msgs(id INTEGER PRIMARY KEY,room TEXT,frm TEXT,txt TEXT,kind TEXT DEFAULT 'text',file TEXT,at INTEGER);
CREATE TABLE IF NOT EXISTS sms(id INTEGER PRIMARY KEY,owner TEXT,num TEXT,txt TEXT,dir TEXT,at INTEGER);
CREATE TABLE IF NOT EXISTS files(id TEXT PRIMARY KEY,mime TEXT,data BLOB,at INTEGER);
CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY,v TEXT);`);
const J=JSON.stringify,Q=(s,...a)=>db.prepare(s).get(...a),QA=(s,...a)=>db.prepare(s).all(...a),X=(s,...a)=>db.prepare(s).run(...a);
const DEF={appName:'T CALL',notice:'',signup:true,rate:0,f:{call:1,sms:1,chat:1,voice:1,upload:1},theme:'green',themesOff:[],allowCustom:true,stun:'stun:stun.l.google.com:19302',turn:'',turnUser:'',turnPass:'',twilio:{sid:'',token:'',from:''}};
const getCfg=()=>{const r=Q('SELECT v FROM kv WHERE k=?','cfg');const c=Object.assign({},DEF,r?JSON.parse(r.v):{});c.f=Object.assign({},DEF.f,c.f);c.twilio=Object.assign({},DEF.twilio,c.twilio);return c};
const setCfg=c=>X('INSERT OR REPLACE INTO kv VALUES(?,?)','cfg',J(c));
const pubCfg=c=>{const {twilio,...r}=c;return Object.assign(r,{smsReady:!!(twilio.sid&&twilio.token&&twilio.from)})};
const SEC=(()=>{let r=Q('SELECT v FROM kv WHERE k=?','secret');if(!r){const v=crypto.randomBytes(32).toString('hex');X('INSERT INTO kv VALUES(?,?)','secret',v);return v}return r.v})();
const mac=p=>crypto.createHmac('sha256',SEC).update(p).digest('base64url');
const sign=u=>{const p=Buffer.from(J({u,e:Date.now()+30*864e5})).toString('base64url');return p+'.'+mac(p)};
const verify=t=>{try{const [p,s]=String(t).split('.');if(mac(p)!==s)return null;const o=JSON.parse(Buffer.from(p,'base64url'));if(o.e<Date.now())return null;const u=Q('SELECT * FROM users WHERE u=?',o.u);return u&&!u.banned?u:null}catch(e){return null}};
const hash=(p,s=crypto.randomBytes(16).toString('hex'))=>s+':'+crypto.scryptSync(p,s,32).toString('hex');
const chk=(p,h)=>{try{const a=Buffer.from(hash(p,h.split(':')[0])),b=Buffer.from(h);return a.length===b.length&&crypto.timingSafeEqual(a,b)}catch(e){return false}};
const pu=u=>({id:u.id,u:u.u,role:u.role,bal:u.bal,vnum:u.vnum,prefs:JSON.parse(u.prefs||'{}'),at:u.at});
const body=req=>new Promise((ok,no)=>{const b=[];let n=0;req.on('data',c=>{n+=c.length;if(n>14e6){no(new Error('Body too large'));req.destroy()}else b.push(c)});req.on('end',()=>ok(Buffer.concat(b).toString()));req.on('error',no)});
const H={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Authorization,Content-Type','Access-Control-Allow-Methods':'GET,POST,PUT,DELETE,OPTIONS'};
const send=(r,c,o,h={})=>{const raw=typeof o==='string'||Buffer.isBuffer(o);r.writeHead(c,Object.assign({'Content-Type':raw?'text/plain':'application/json'},H,h));r.end(raw?o:J(o))};
const tries=new Map();const limited=ip=>{const t=tries.get(ip)||{n:0,t:Date.now()};if(Date.now()-t.t>6e5){t.n=0;t.t=Date.now()}t.n++;tries.set(ip,t);return t.n>30};
const online=new Map(),active=new Map(),sse=new Map();
const SSE_T=new Set(['incoming','msg','sms','missed','notice','ended']);
const reach=u=>online.has(u)||sse.has(u);
const slim=(o,u)=>o.t==='incoming'?{t:o.t,from:o.from,cid:o.cid,video:o.video}:o.t==='msg'?(o.m.frm===u?null:{t:'msg',m:{frm:o.m.frm,txt:o.m.txt,kind:o.m.kind}}):o.t==='ended'?{t:'ended',cid:o.cid}:o;
const push=(u,o)=>{const s=online.get(u);if(s)s.forEach(w=>w.readyState===1&&w.send(J(o)));
 if(SSE_T.has(o.t)){const e=sse.get(u),x=e&&slim(o,u);if(x)e.forEach(r=>r.write('data: '+J(x)+'\n\n'))}};
const room=(me,r)=>r==='general'?'general':'dm:'+[me,String(r).replace(/^dm:/,'')].sort().join('|');
const lookup=q=>{q=String(q||'').trim().toLowerCase();return q?Q('SELECT * FROM users WHERE u=? OR (vnum<>\'\' AND vnum=?)',q,q):null};
function saveMsg(me,d){const c=getCfg();if(!c.f.chat)throw new Error('Chat is turned off by the admin');const kind=['text','voice','img'].includes(d.kind)?d.kind:'text';
 if(kind==='voice'&&!c.f.voice)throw new Error('Voice messages are turned off');if(kind==='img'&&!c.f.upload)throw new Error('Uploads are turned off');
 const txt=String(d.txt||'').slice(0,4000);if(!txt&&!d.file)throw new Error('Empty message');
 const rm=room(me,d.room),at=Date.now();const r=X('INSERT INTO msgs(room,frm,txt,kind,file,at) VALUES(?,?,?,?,?,?)',rm,me,txt,kind,d.file||null,at);
 const m={id:Number(r.lastInsertRowid),room:rm,frm:me,txt,kind,file:d.file||null,at};
 if(rm==='general')online.forEach((s,u)=>push(u,{t:'msg',m}));else rm.slice(3).split('|').forEach(u=>push(u,{t:'msg',m}));return m}
function logCall(a,b,num,st,line){return Number(X('INSERT INTO calls(caller,callee,num,at,st,line) VALUES(?,?,?,?,?,?)',a,b,num,Date.now(),st,line||'1').lastInsertRowid)}
function finish(cid,by){const a=active.get(cid);if(!a)return;active.delete(cid);clearTimeout(a.tm);if(!a.start)push(a.b,{t:'missed',from:a.a,cid});const c=getCfg();const dur=a.start?Math.round((Date.now()-a.start)/1000):0;
 const cost=(+c.rate>0&&dur)?Math.ceil(dur/60)*c.rate:0;if(cost)X('UPDATE users SET bal=bal-? WHERE u=?',cost,a.a);
 X('UPDATE calls SET st=?,dur=?,cost=? WHERE id=?',a.start?'done':'miss',dur,cost,cid);push(a.a,{t:'ended',cid,dur,cost});push(a.b,{t:'ended',cid,dur,cost})}
function onWs(ws,raw){let d;try{d=JSON.parse(raw)}catch(e){return}const me=ws.user,say=o=>ws.readyState===1&&ws.send(J(o));
 try{switch(d.t){
 case 'msg':{const m=saveMsg(me,d);say({t:'sent',tmp:d.tmp,m});break}
 case 'call':{const c=getCfg();if(!c.f.call)return say({t:'error',m:'Calls are turned off by the admin'});const to=lookup(d.to);if(!to||to.banned||to.u===me)return say({t:'unavailable',m:'No T CALL user with that name or number'});
  const mu=Q('SELECT * FROM users WHERE u=?',me);if(+c.rate>0&&mu.bal<+c.rate)return say({t:'error',m:'Wallet balance is low, please recharge'});
  if(!reach(to.u)){logCall(me,to.u,d.to,'miss',d.line);return say({t:'unavailable',m:to.u+' is offline'})}
  const id=logCall(me,to.u,d.to,'ringing',d.line);const ac={id,a:me,b:to.u,start:0,sdp:d.sdp,video:!!d.video,q:[]};ac.tm=setTimeout(()=>{const x=active.get(id);if(x&&!x.start){push(x.a,{t:'unavailable',m:'No answer'});finish(id,x.a)}},45000);active.set(id,ac);push(to.u,{t:'incoming',cid:id,from:me,sdp:d.sdp,video:!!d.video});say({t:'ringing',cid:id,to:to.u});break}
 case 'answer':{const a=active.get(d.cid);if(!a||a.b!==me)return;a.start=Date.now();clearTimeout(a.tm);X('UPDATE calls SET st=? WHERE id=?','answered',a.id);push(a.a,{t:'answer',cid:a.id,sdp:d.sdp});break}
 case 'ice':{const a=active.get(d.cid);if(!a)return;const to=a.a===me?a.b:a.a;if(to===a.b&&!a.start&&!online.has(to))a.q.push(d.cand);else push(to,{t:'ice',cid:a.id,cand:d.cand});break}
 case 'reject':{const a=active.get(d.cid);if(!a||a.b!==me)return;X('UPDATE calls SET st=? WHERE id=?','rej',a.id);clearTimeout(a.tm);active.delete(a.id);push(a.a,{t:'rejected',cid:a.id});break}
 case 'end':finish(d.cid,me);break}}catch(e){say({t:'error',m:e.message})}}
function twilio(c,to,txt){return new Promise((ok,no)=>{const f=new URLSearchParams({To:to,From:c.twilio.from,Body:txt}).toString();
 const r=https.request({host:'api.twilio.com',path:`/2010-04-01/Accounts/${c.twilio.sid}/Messages.json`,method:'POST',auth:c.twilio.sid+':'+c.twilio.token,headers:{'Content-Type':'application/x-www-form-urlencoded','Content-Length':Buffer.byteLength(f)}},s=>{let b='';s.on('data',x=>b+=x);s.on('end',()=>s.statusCode<300?ok():no(new Error('Provider error '+s.statusCode+': '+b.slice(0,160))))});r.on('error',no);r.end(f)})}
const series=(rows)=>{const out=[];for(let i=6;i>=0;i--){const d=new Date();d.setHours(0,0,0,0);d.setDate(d.getDate()-i);const s=+d,e=s+864e5;out.push({d:d.getDate(),n:rows.filter(r=>r.at>=s&&r.at<e).length})}return out};
const server=http.createServer(async(req,res)=>{try{
 const u=new URL(req.url,'http://x'),p=u.pathname,m=req.method;if(m==='OPTIONS')return send(res,204,'');
 if(p==='/'||p==='/index.html')return send(res,200,fs.readFileSync(path.join(__dirname,'public','index.html')),{'Content-Type':'text/html; charset=utf-8'});
 if(p==='/api/ping')return send(res,200,{ok:true,name:'T SERVER',v:'1.0',empty:!Q('SELECT COUNT(*) c FROM users').c});
 let f=p.match(/^\/files\/(\w+)$/);if(f){const r=Q('SELECT * FROM files WHERE id=?',f[1]);if(!r)return send(res,404,{error:'not found'});return send(res,200,Buffer.from(r.data),{'Content-Type':r.mime,'Cache-Control':'public,max-age=31536000'})}
 const raw=m==='GET'?'':await body(req);
 if(p==='/twilio/sms'&&m==='POST'){const q=new URLSearchParams(raw),to=q.get('To'),w=to&&Q('SELECT * FROM users WHERE vnum=?',to);if(w){X('INSERT INTO sms(owner,num,txt,dir,at) VALUES(?,?,?,?,?)',w.u,q.get('From'),q.get('Body')||'','in',Date.now());push(w.u,{t:'sms',num:q.get('From'),txt:q.get('Body')})}return send(res,200,'<Response/>',{'Content-Type':'text/xml'})}
 let b={};try{b=raw?JSON.parse(raw):{}}catch(e){}
 const c=getCfg(),ip=req.socket.remoteAddress;
 if(p==='/api/signup'||p==='/api/login'){if(limited(ip))return send(res,429,{error:'Too many tries, wait a few minutes'});const un=String(b.u||'').trim().toLowerCase(),pw=String(b.p||'');
  if(p==='/api/signup'){const first=!Q('SELECT COUNT(*) c FROM users').c;if(!first&&!c.signup)return send(res,403,{error:'Signups are closed by the admin'});
   if(!/^[a-z0-9_]{3,20}$/.test(un))return send(res,400,{error:'Username: 3-20 letters, numbers or _'});if(pw.length<6)return send(res,400,{error:'Password needs 6+ characters'});
   if(Q('SELECT 1 x FROM users WHERE u=?',un))return send(res,409,{error:'Username already taken'});const ni=X('INSERT INTO users(u,pw,role,at) VALUES(?,?,?,?)',un,hash(pw),first?'admin':'user',Date.now());X('UPDATE users SET vnum=? WHERE id=?',String(1000+Number(ni.lastInsertRowid)),Number(ni.lastInsertRowid))}
  const w=Q('SELECT * FROM users WHERE u=?',un);if(!w||!chk(pw,w.pw))return send(res,401,{error:'Wrong username or password'});if(w.banned)return send(res,403,{error:'This account is blocked'});
  return send(res,200,{token:sign(w.u),user:pu(w),cfg:pubCfg(c)})}
 const me=verify((req.headers.authorization||'').replace('Bearer ',''));if(!me)return send(res,401,{error:'Login required'});
 const ok=o=>send(res,200,o);
 if(p==='/api/events'){res.socket.setTimeout(0);res.writeHead(200,Object.assign({'Content-Type':'text/event-stream','Cache-Control':'no-cache'},H));res.write(': ok\n\n');if(!sse.has(me.u))sse.set(me.u,new Set());sse.get(me.u).add(res);const hb=setInterval(()=>res.write(': hb\n\n'),25000);req.on('close',()=>{clearInterval(hb);const e=sse.get(me.u);if(e){e.delete(res);if(!e.size)sse.delete(me.u)}});return}
 if(p==='/api/me')return ok({user:pu(me),cfg:pubCfg(c)});
 if(p==='/api/prefs'&&m==='PUT'){const o={};for(const k of ['theme','accent','fs','compact','letters','ring','lang','vib'])if(k in b)o[k]=b[k];const cur=Object.assign(JSON.parse(me.prefs||'{}'),o);X('UPDATE users SET prefs=? WHERE id=?',J(cur).slice(0,2000),me.id);return ok({prefs:cur})}
 if(p==='/api/contacts'){if(m==='GET')return ok(QA('SELECT id,name,phone FROM contacts WHERE owner=? ORDER BY name',me.u));
  if(m==='POST'){const n=String(b.name||'').trim().slice(0,60),ph=String(b.phone||'').trim().slice(0,40);if(!n||!ph)return send(res,400,{error:'Name and number needed'});X('INSERT INTO contacts(owner,name,phone) VALUES(?,?,?)',me.u,n,ph);return ok({ok:1})}}
 if((f=p.match(/^\/api\/contacts\/(\d+)$/))&&m==='DELETE'){X('DELETE FROM contacts WHERE id=? AND owner=?',+f[1],me.u);return ok({ok:1})}
 if(p==='/api/calls'){if(m==='GET')return ok(QA('SELECT * FROM calls WHERE caller=? OR callee=? ORDER BY id DESC LIMIT 200',me.u,me.u));
  if(m==='POST'){logCall(me.u,'',String(b.num||'').slice(0,40),'failed',b.line);return ok({ok:1})}}
 if(p==='/api/lookup'){const w=lookup(u.searchParams.get('q'));return ok(w&&!w.banned?{u:w.u,online:online.has(w.u)}:null)}
 if(p==='/api/rooms'){const us=QA('SELECT u FROM users WHERE banned=0 AND u<>? ORDER BY u',me.u).map(x=>{const r=room(me.u,x.u),l=Q('SELECT txt,kind,at FROM msgs WHERE room=? ORDER BY id DESC LIMIT 1',r);return {u:x.u,online:online.has(x.u),last:l||null}});
  return ok({users:us,general:Q('SELECT txt,kind,at,frm FROM msgs WHERE room=? ORDER BY id DESC LIMIT 1','general')||null})}
 if(p==='/api/msgs')return ok(QA('SELECT * FROM msgs WHERE room=? ORDER BY id DESC LIMIT 200',room(me.u,u.searchParams.get('room')||'general')).reverse());
 if(p==='/api/msg'&&m==='POST')return ok(saveMsg(me.u,b));
 if(p==='/api/upload'&&m==='POST'){if(!c.f.upload)return send(res,403,{error:'Uploads are turned off'});const mime=String(b.mime||'');if(!/^(image|audio)\//.test(mime))return send(res,400,{error:'Only image or audio'});
  const buf=Buffer.from(String(b.data||''),'base64');if(!buf.length||buf.length>8e6)return send(res,400,{error:'File empty or over 8 MB'});const id=crypto.randomBytes(12).toString('hex');X('INSERT INTO files VALUES(?,?,?,?)',id,mime,buf,Date.now());return ok({id})}
 if(p==='/api/sms'){if(m==='GET')return ok(QA('SELECT * FROM sms WHERE owner=? ORDER BY id DESC LIMIT 100',me.u));
  if(m==='POST'){if(!c.f.sms)return send(res,403,{error:'SMS is turned off by the admin'});if(!(c.twilio.sid&&c.twilio.token&&c.twilio.from))return send(res,400,{error:'The admin has not set an SMS provider yet'});
   const to=String(b.to||'').trim(),txt=String(b.txt||'').slice(0,600);if(!to||!txt)return send(res,400,{error:'Number and message needed'});await twilio(c,to,txt);X('INSERT INTO sms(owner,num,txt,dir,at) VALUES(?,?,?,?,?)',me.u,to,txt,'out',Date.now());return ok({ok:1})}}
 if(p.startsWith('/api/admin')){if(me.role!=='admin')return send(res,403,{error:'Admins only'});
  if(p==='/api/admin/stats'){const n=t=>Q(`SELECT COUNT(*) c FROM ${t}`).c;return ok({users:n('users'),calls:n('calls'),msgs:n('msgs'),sms:n('sms'),files:n('files'),online:online.size,earned:Q('SELECT COALESCE(SUM(cost),0) c FROM calls').c,
    users7:series(QA('SELECT at FROM users')),calls7:series(QA('SELECT at FROM calls WHERE at>?',Date.now()-8*864e5))})}
  if(p==='/api/admin/users')return ok(QA('SELECT id,u,role,banned,bal,vnum,at FROM users ORDER BY id').map(x=>Object.assign(x,{online:online.has(x.u)})));
  if(p==='/api/admin/user'&&m==='POST'){const w=Q('SELECT * FROM users WHERE id=?',+b.id);if(!w)return send(res,404,{error:'No such user'});
   if(w.id===me.id&&(b.banned||b.role==='user'))return send(res,400,{error:'You cannot demote or block yourself'});
   if('role' in b)X('UPDATE users SET role=? WHERE id=?',b.role==='admin'?'admin':'user',w.id);if('banned' in b)X('UPDATE users SET banned=? WHERE id=?',b.banned?1:0,w.id);
   if('add' in b)X('UPDATE users SET bal=bal+? WHERE id=?',+b.add||0,w.id);if('vnum' in b)X('UPDATE users SET vnum=? WHERE id=?',String(b.vnum).trim(),w.id);
   if(b.pass){if(String(b.pass).length<6)return send(res,400,{error:'Password needs 6+ characters'});X('UPDATE users SET pw=? WHERE id=?',hash(String(b.pass)),w.id)}
   if(b.banned)online.get(w.u)?.forEach(s=>s.close());return ok({ok:1})}
  if((f=p.match(/^\/api\/admin\/user\/(\d+)$/))&&m==='DELETE'){const w=Q('SELECT * FROM users WHERE id=?',+f[1]);if(!w||w.id===me.id)return send(res,400,{error:'Cannot delete this user'});
   for(const t of ['contacts','sms'])X(`DELETE FROM ${t} WHERE owner=?`,w.u);X('DELETE FROM users WHERE id=?',w.id);online.get(w.u)?.forEach(s=>s.close());return ok({ok:1})}
  if(p==='/api/admin/settings'){if(m==='GET')return ok(c);const n=Object.assign({},c,b);n.f=Object.assign({},c.f,b.f||{});n.twilio=Object.assign({},c.twilio,b.twilio||{});setCfg(n);online.forEach((s,k)=>push(k,{t:'cfg',cfg:pubCfg(n)}));return ok(n)}
  if(p==='/api/admin/logs')return ok({calls:QA('SELECT * FROM calls ORDER BY id DESC LIMIT 60'),sms:QA('SELECT * FROM sms ORDER BY id DESC LIMIT 60'),msgs:QA('SELECT id,room,frm,txt,kind,at FROM msgs ORDER BY id DESC LIMIT 60')});
  if(p==='/api/admin/broadcast'&&m==='POST'){const t=String(b.text||'').slice(0,300);if(b.pin){c.notice=t;setCfg(c)}online.forEach((s,k)=>push(k,{t:'notice',text:t}));return ok({ok:1})}
  if(p==='/api/admin/clear'&&m==='POST'){const t={calls:'calls',sms:'sms',msgs:'msgs',files:'files'}[b.what];if(!t)return send(res,400,{error:'Unknown'});X(`DELETE FROM ${t}`);return ok({ok:1})}}
 send(res,404,{error:'Not found'})}catch(e){send(res,500,{error:String(e.message||e)})}});
const wss=new WebSocketServer({noServer:true});
server.on('upgrade',(req,sock,head)=>{const w=verify(new URL(req.url,'http://x').searchParams.get('token'));if(!w){sock.destroy();return}
 wss.handleUpgrade(req,sock,head,ws=>{ws.user=w.u;if(!online.has(w.u))online.set(w.u,new Set());online.get(w.u).add(ws);online.forEach((s,k)=>push(k,{t:'presence',u:w.u,on:1}));
  for(const a of active.values())if(a.b===w.u&&!a.start){ws.send(J({t:'incoming',cid:a.id,from:a.a,sdp:a.sdp,video:a.video}));a.q.forEach(c=>ws.send(J({t:'ice',cid:a.id,cand:c})));a.q=[]}
  ws.on('message',m=>onWs(ws,String(m)));ws.on('close',()=>{const s=online.get(w.u);s.delete(ws);if(!s.size){online.delete(w.u);for(const [id,a] of active)if(a.a===w.u||a.b===w.u)finish(id,w.u);online.forEach((x,k)=>push(k,{t:'presence',u:w.u,on:0}))}})})});
server.listen(PORT,()=>console.log('T SERVER running on port '+PORT));
