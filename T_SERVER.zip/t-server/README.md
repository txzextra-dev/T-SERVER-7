# T SERVER

T CALL app ka apna backend. Supabase ki jagah ye ek hi server hai.

Isme hai: login (pehla user admin), cloud save (contacts, calls, chat, wallet, settings, themes),
realtime chat, voice message, photo, app-to-app voice aur video call (WebRTC), wallet aur call billing,
SMS (Twilio se), admin API, aur T CALL ki web app (`/` pe khulti hai).

## Chalane ke liye
Node.js 22.5 ya naya chahiye (SQLite andar hi hai).

    npm install
    npm start

Server http://localhost:3000 pe chalega. Data `data/` folder me save hota hai (`tserver.db` aur files).
Doosri jagah rakhna ho to `DATA_DIR=/path` set karo. Port badalna ho to `PORT=8080`.

## Internet pe rakhna (taaki sab phones se chale)
- **VPS** (sabse aasan aur data safe): Ubuntu VPS le lo, Node 22 install karo, folder daalo, `npm install`,
  phir `pm2 start server.js` ya Docker chalao. Domain + HTTPS ke liye Caddy ya Nginx lagao.
- **Docker:** `docker build -t tserver .` phir `docker run -d -p 3000:3000 -v tdata:/data tserver`
- **Render, Railway:** chalega, par `data` ke liye paid disk (volume) lo, free plan me restart par data ud jata hai.
- **Phone me (Termux):** `pkg install nodejs`, folder daalo, `npm install`, `npm start`. Isse sirf same WiFi
  ke phones chalenge, jab tak server ko internet pe public na karo.

HTTPS zaroori hai agar T CALL web se khologe (microphone ke liye). Android app me HTTP bhi chal jata hai.

## T CALL app me
App kholo, server ka address daalo (jaise `https://tserver.mydomain.com`), phir sign up.
Jo pehla sign up karega wo admin hoga. Isliye server chalate hi sabse pehle khud sign up karo.

## App band ho tab bhi notification
Android app me ek chhoti background service chalti hai (upar ek "Ready for calls and messages" notification dikhti hai).
Isse app band hone par bhi incoming call, message, SMS aur missed call ka notification aata hai.
Notification dabane par app khulta hai aur call wahi se uthti hai. Ye Firebase ke bina chalta hai.
Kuch phones (Xiaomi, Oppo, Vivo, Realme) battery saver me service band kar dete hain. Phone ki settings me
T CALL ko "No restrictions" ya "Autostart" allow karo.

## Calls ke baare me
- T CALL users ke beech voice aur video call seedha chalti hai. Har user ko ek number milta hai (1001, 1002...).
  Admin isse apna koi bhi number (jaise virtual number) set kar sakta hai.
- Jio, Airtel ke normal numbers pe call is server me nahi hai. Uske liye telecom provider ki voice API chahiye.
- Alag alag internet (mobile data, WiFi) ke beech call na lage to Admin, Settings me TURN server daalo.
- SMS: Admin, Settings me Twilio ki SID, token, number daalo. Incoming SMS ke liye Twilio me webhook
  `https://tumhara-server/twilio/sms` lagao, aur user ko wahi Twilio number do (Admin, Users, Set number).

## Security
- Pehle HTTPS lagao, phir logo ko do.
- Admin ka password mazboot rakho. Login ke 30 galat try ke baad kuch der ruk jata hai.
- `data/` ka backup lete raho.
